<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; padding: 20px; background-color: #f8f9fa;">
    <div style="background: white; padding: 30px; border-radius: 8px; border: 1px solid #ddd;">

        
        <div style="font-size: 16px; color: #333; line-height: 1.6;">
            <?php echo $messageContent; ?>

        </div>

        <hr style="margin-top: 30px; border: 0; border-top: 1px solid #eee;">
        <p style="text-align: center; font-size: 12px; color: #999;">
            Sent from Flash 360 Degree Admin Panel.
        </p>
    </div>
</body>
</html><?php /**PATH D:\laravell\mynews\news-backend\resources\views/emails/custom.blade.php ENDPATH**/ ?>